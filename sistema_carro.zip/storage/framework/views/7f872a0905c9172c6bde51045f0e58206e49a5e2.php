<?php $__env->startSection('title', 'Cadastro Página Dinâmica'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert <?php echo e(session('typeMessage') === 'success' ? 'alert-success' : 'alert-warning'); ?>">
            <p><?php echo e(session('message')); ?></p>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Cadastro Página Dinâmica</h3><br/>
                    <small>Cadastro de uma nova página dinâmica</small>
                </div>
                <form action="<?php echo e(route('config.pageDyncamic.insert')); ?>" enctype="multipart/form-data" id="formRegister" method="POST">
                    <div class="card-body">
                        <?php if(isset($errors) && count($errors) > 0): ?>
                            <div class="alert alert-warning">
                                <h4>Existem erros no envio do formulário, veja abaixo para corrigi-los.</h4>
                                <ol>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        <?php endif; ?>
                        <div class="error-form alert alert-warning display-none">
                            <h4>Existem erros no envio do formulário, veja abaixo para corrigi-los.</h4>
                            <ol></ol>
                        </div>
                        <div class="row">
                            <div class="col-md-10">
                                <div class="form-group">
                                    <label for="nome">Nome da Página</label>
                                    <input type="text" class="form-control" name="nome" id="nome">
                                    <small>Não deve conter espaços, acentos e caracteres especiais. Sua página fica como seudominio.com.br/pagina/<b>[NOME]</b></small>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group clearfix">
                                    <div class="icheck-primary d-inline">
                                        <label for="ativo">Ativo</label><br/>
                                        <input type="checkbox" name="ativo" id="ativo">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label>Conteúdo da Página</label>
                                    <textarea name="conteudo" id="conteudo"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer d-flex justify-content-between flex-wrap">
                        <a href="<?php echo e(route('config.pageDyncamic.listagem')); ?>" class="btn btn-primary col-md-3"><i class="fa fa-arrow-left"></i> Voltar</a>
                        <button class="btn btn-success col-md-3" id="btnCadastrar"><i class="fa fa-save"></i> Cadastrar</button>
                    </div>
                    <?php echo csrf_field(); ?>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/jquery-validation/dist/jquery.validate.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/icheck2/icheck.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/ckeditor4/ckeditor.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/ckeditor4/config.js')); ?>"></script>

    <script src="https://cdn.ckeditor.com/ckeditor5/22.0.0/classic/ckeditor.js"></script>
    <script>
        $(document).ready(function() {
            $('#ativo').icheck({
                checkboxClass: 'icheckbox_minimal-blue',
                radioClass: 'iradio_minimal',
                increaseArea: '20%' // optional
            });

            CKEDITOR.replace( 'conteudo', {
                //extraPlugins: 'easyimage',
                //removePlugins: 'image',
                //cloudServices_tokenUrl: "<?php echo e(route('ajax.ckeditor.getToken')); ?>",
                filebrowserUploadUrl: "<?php echo e(route('ajax.ckeditor.uploadImages', ['_token' => csrf_token() ])); ?>",
                filebrowserUploadMethod: 'form'
            } );


            // Validar dados
            const container = $("div.error-form");
            // validate the form when it is submitted
            $("#formCadastroAutos, #formAlteraAutos").validate({
                errorContainer: container,
                errorLabelContainer: $("ol", container),
                wrapper: 'li',
                rules: {
                    nome: {
                        required: true
                    },
                    conteudo: {
                        required: true
                    }
                },
                highlight: function( element, errorClass, validClass ) {
                    if ( element.type === "radio" ) {
                        this.findByName( element.name ).addClass( errorClass ).removeClass( validClass );
                    } else {
                        $( element ).addClass( errorClass ).removeClass( validClass );
                    }

                    // select2
                    if( $(element).hasClass('select2-hidden-accessible') ){
                        dzik = $(element).next('span.select2');
                        if(dzik)
                            dzik.addClass( errorClass ).removeClass( validClass );
                    }

                },
                unhighlight: function( element, errorClass, validClass ) {
                    if ( element.type === "radio" ) {
                        this.findByName( element.name ).removeClass( errorClass ).addClass( validClass );
                    } else {
                        $( element ).removeClass( errorClass ).addClass( validClass );
                    }

                    // select2
                    if( $(element).hasClass('select2-hidden-accessible') ){
                        dzik = $(element).next('span.select2');
                        if(dzik)
                            dzik.removeClass( errorClass ).addClass( validClass );
                    }
                },
                submitHandler: function(form) {
                    form.submit();
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css_pre'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/iCheck/1.0.3/skins/all.min.css">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', ['breadcrumb' => ['home' => false,'active' => 'Cadastro Página Dinâmica', 'no-active' => [['route' => 'config.pageDyncamic.listagem', 'name' => 'Listagem Página Dinâmica']]]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projetos\sistema_carro\resources\views/auth/config/pageDynamic/register.blade.php ENDPATH**/ ?>