<?php $__env->startSection('title', 'Início'); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin=""/>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('css_pre'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js_head'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
    <script>

        $(function () {

            getOrderHomePage();

        });

        const getOrderHomePage = () => {
            $.get(`${window.location.origin}/ajax/config/ordem-pagina-inicial`, data => {
                $.each(data, function (key, value) {
                    switch (value.id) {
                        case 1:
                            getBlogHomePage();
                            break;
                        case 2:
                            getTestimonyHomePage();
                            break;
                        case 3:
                            getBannerHomePage();
                            break;
                        case 4:
                            getAutosFeatured();
                            break;
                        case 5:
                            getFilterHomePage();
                            break;
                        case 6:
                            getAutosRecents();
                            break;
                        case 7:
                            getMapLocationStore();
                            break;
                    }
                });
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="order-home-page"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.template.page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projetos\sistema_carro\resources\views/user/home/index.blade.php ENDPATH**/ ?>