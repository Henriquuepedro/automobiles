<div class="modal fade" id="updateUser" tabindex="-1" role="dialog" aria-labelledby="newUserModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content card">
            <form action="<?php echo e(route('ajax.user.update')); ?>" method="post" enctype="multipart/form-data" id="formUpdateUser">
                <div class="modal-header">
                    <h5 class="modal-title" id="newUserModalLabel">Atualizar Usuário</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Nome do Usuário</label>
                            <input type="text" class="form-control" name="name_user">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Endereço de Email</label>
                            <input type="email" class="form-control" name="email_user">
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12">
                            <label>Loja</label>
                            <select class="select2 form-control" multiple name="store_user[]">
                                <?php $__currentLoopData = $dataStores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($store['id']); ?>"><?php echo e($store['store_fancy']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-12 alert alert-info">
                            <p>Caso não pretenda atualizar a senha, deixe os campos abaixo em branco</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <label>Senha de Acesso</label>
                            <input type="password" class="form-control" name="password_user">
                        </div>
                        <div class="form-group col-md-6">
                            <label>Confirme a Senha</label>
                            <input type="password" class="form-control" name="password_user_confirmation">
                        </div>
                    </div>
                </div>
                <div class="modal-footer d-flex justify-content-between">
                    <button type="button" class="btn btn-secondary col-md-3" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary col-md-3"><i class="fa fa-save"></i> Atualizar</button>
                </div>
                <input type="hidden" name="user_id">
            </form>
            <div class="overlay dark d-none screen-user-edit">
                <i class="fas fa-3x fa-sync-alt fa-spin"></i>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Projetos\sistema_carro\resources\views/admin/company/users/modalUpdate.blade.php ENDPATH**/ ?>