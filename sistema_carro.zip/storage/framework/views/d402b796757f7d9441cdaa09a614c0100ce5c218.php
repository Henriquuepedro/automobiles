        <!-- Footer start -->
        <footer class="footer overview-bgi">
            <div class="container footer-inner">
                <div class="row">
                    <div class="col-xl-4 col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item clearfix">
                            <img src="<?php echo e(asset('assets/img/logos/logo.png')); ?>" alt="logo" class="f-logo">
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <div class="text">
                                <P>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae lectus suscipit, et pulvinar nisi tincidunt. Aliquam erat.</P>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item clearfix">
                            <h4>
                                Contact Info
                            </h4>
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <ul class="contact-info">
                                <li>
                                    <i class="flaticon-pin"></i>20/F Green Road, Dhanmondi, Dhaka
                                </li>
                                <li>
                                    <i class="flaticon-mail"></i><a href="mailto:sales@hotelempire.com">info@themevessel.com</a>
                                </li>
                                <li>
                                    <i class="flaticon-phone"></i><a href="tel:+55-417-634-7071">+0477 85X6 552</a>
                                </li>
                                <li>
                                    <i class="flaticon-fax"></i>+0477 85X6 552
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-item">
                            <h4>
                                Useful Links
                            </h4>
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <ul class="links">
                                <li>
                                    <a href="#"><i class="fa fa-angle-right"></i>Home</a>
                                </li>
                                <li>
                                    <a href="about.html"><i class="fa fa-angle-right"></i>About Us</a>
                                </li>
                                <li>
                                    <a href="services.html"><i class="fa fa-angle-right"></i>Services</a>
                                </li>
                                <li>
                                    <a href="car-list-rightside.html"><i class="fa fa-angle-right"></i>Car Listing</a>
                                </li>
                                <li>
                                    <a href="blog-details.html"><i class="fa fa-angle-right"></i>Blog</a>
                                </li>
                                <li>
                                    <a href="contact.html"><i class="fa fa-angle-right"></i>Contact Us</a>
                                </li>
                                <li>
                                    <a href="elements.html"><i class="fa fa-angle-right"></i>Elements</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item clearfix">
                            <h4>Subscribe</h4>
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <div class="Subscribe-box">
                                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.</p>
                                <form class="form-inline" action="#" method="GET">
                                    <input type="text" class="form-control mb-sm-0" id="inlineFormInputName3" placeholder="Email Address">
                                    <button type="submit" class="btn"><i class="fa fa-paper-plane"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <p class="copy">© 2019 <a href="#">Theme Vessel.</a> All Rights Reserved.</p>
                        </div>
                        <div class="col-lg-6">
                            <div class="social-list-2">
                                <ul>
                                    <li><a href="#" class="facebook-bg"><i class="fa fa-facebook"></i></a></li>
                                    <li><a href="#" class="twitter-bg"><i class="fa fa-twitter"></i></a></li>
                                    <li><a href="#" class="google-bg"><i class="fa fa-google-plus"></i></a></li>
                                    <li><a href="#" class="linkedin-bg"><i class="fa fa-linkedin"></i></a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer end -->

        <!-- Full Page Search -->
        <div id="full-page-search">
            <button type="button" class="close">×</button>
            <form action="index.html#">
                <input type="search" value="" placeholder="type keyword(s) here" />
                <button type="submit" class="btn btn-sm button-theme">Search</button>
            </form>
        </div>

        <!-- Car Overview Modal -->
        <div class="car-model-2">
            <div class="modal fade" id="carOverviewModal" tabindex="-1" role="dialog" aria-labelledby="carOverviewModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="modal-title" id="carOverviewModalLabel">
                                <h4>Find Your Dream Car</h4>
                                <h5><i class="flaticon-pin"></i> 123 Kathal St. Tampa City,</h5>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row modal-raw">
                                <div class="col-lg-6 modal-left">
                                    <div class="item active">
                                        <img src="<?php echo e(asset('assets/img/car-11.png')); ?>" alt="best-car" class="img-fluid">
                                        <div class="sobuz">
                                            <div class="price-box">
                                                <span class="del"><del>$950.00</del></span>
                                                <br>
                                                <span class="del-2">$1050.00</span>
                                            </div>
                                            <div class="ratings-2">
                                                <span class="ratings-box">4.5/5</span>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star"></i>
                                                <i class="fa fa-star-o"></i>
                                                ( 7 Reviews )
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 modal-right">
                                    <div class="modal-right-content">
                                        <section>
                                            <h3>Features</h3>
                                            <div class="features">
                                                <ul class="bullets">
                                                    <li>Cruise Control</li>
                                                    <li>Airbags</li>
                                                    <li>Air Conditioning</li>
                                                    <li>Alarm System</li>
                                                    <li>Audio Interface</li>
                                                    <li>CDR Audio</li>
                                                    <li>Seat Heating</li>
                                                    <li>ParkAssist</li>
                                                </ul>
                                            </div>
                                        </section>
                                        <section>
                                            <h3>Overview</h3>
                                            <ul class="bullets">
                                                <li>Model</li>
                                                <li>Year</li>
                                                <li>Condition</li>
                                                <li>Price</li>
                                                <li>Audi</li>
                                                <li>2020</li>
                                                <li>Brand New</li>
                                                <li>$178,000</li>
                                            </ul>
                                        </section>
                                        <div class="description">
                                            <h3>Description</h3>
                                            <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard.</p>
                                            <a href="car-details.html" class="btn btn-md btn-round btn-theme">Show Detail</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="<?php echo e(asset('assets/js/jquery-2.2.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap-submenu.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/rangeslider.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.mb.YTPlayer.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.easing.1.3.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.scrollUp.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/dropzone.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.filterizr.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.countdown.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.mousewheel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/lightgallery-all.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jnoty.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/sidebar.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="<?php echo e(asset('assets/js/ie10-viewport-bug-workaround.js')); ?>"></script>
        <!-- Custom javascript -->
        <script src="<?php echo e(asset('assets/js/ie10-viewport-bug-workaround.js')); ?>"></script>

        <?php echo $__env->yieldContent('js_template'); ?>
    </body>
</html>
<?php /**PATH C:\Projetos\sistema_carro\resources\views/user/template/footer.blade.php ENDPATH**/ ?>