<div class="tab-pane" id="users">
    <div class="row">
        <div class="col-md-12 form-group d-flex justify-content-end">
            <button class="btn btn-primary col-md-4" data-toggle="modal" data-target="#newUser" id="registerNewUser">Novo Usuário</button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 form-group">
            <table id="tableUsers"  class="table table-bordered table-striped col-md-12">
                <thead>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Ações</th>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->startSection('js_form_user'); ?>
    <script type="text/javascript" src="<?php echo e(asset('assets/admin/dist/js/pages/users/users.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Projetos\sistema_carro\resources\views/admin/company/users/form.blade.php ENDPATH**/ ?>