<?php $__env->startSection('title', 'Listagem Automóveis'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
    <div class="alert <?php echo e(session('typeMessage') === 'success' ? 'alert-success' : 'alert-warning'); ?>">
        <p><?php echo e(session('message')); ?></p>
    </div>
    <?php endif; ?>
    <div class="box">
        <div class="box-body">
            <div class="card">
                <div class="card-header">
                    <div class="col-md-10 pull-left">
                        <h3 class="card-title">Listagem de Automóveis</h3><br/>
                        <small>Listagem de todos os automóveis cadastrados</small>
                    </div>
                    <div class="col-md-2 pull-right text-right text-xs-center">
                        <a href="<?php echo e(route('admin.automoveis.cadastro')); ?>" class="btn btn-primary">Novo Automovel</a>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered table-striped dataTable" id="tableAutos">
                        <thead>
                            <tr>
                                <th width="10%">Imagem</th>
                                <th width="60%">Marca / Modelo</th>
                                <th width="15%">Cor / Ano</th>
                                <th width="15%">Valor / Kms</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $dataAutos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $automovel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-url="<?php echo e(route('admin.automoveis.edit', ['codAuto' => $automovel['codauto']])); ?>">
                                <td class="text-center"><img height="60" src="<?php echo e(asset($automovel['path'])); ?>" /></td>
                                <td><?php if($automovel['destaque']): ?><b class="text-yellow"><i class="fa fa-star"></i> DESTAQUE </b><br/><?php endif; ?><?php echo e($automovel['marca']); ?> <br/> <?php echo e($automovel['modelo']); ?></td>
                                <td><?php echo e($automovel['cor']); ?> <br/> <?php echo e($automovel['ano']); ?></td>
                                <td><?php echo e($automovel['valor']); ?> <br/> <?php echo e($automovel['kms']); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Imagem</th>
                                <th>Marca / Modelo</th>
                                <th>Cor / Ano</th>
                                <th>Valor / Kms</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
    <script src="//cdn.datatables.net/plug-ins/1.10.20/i18n/Portuguese-Brasil.json"></script>
    <script>
        $('table tr').click(function(){
            window.location = $(this).data('url');
            return false;
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', ['breadcrumb' => ['home' => false,'active' => 'Listagem Automóveis', 'no-active' => []]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projetos\sistema_carro\resources\views/admin/cadastros/automoveis/listagem.blade.php ENDPATH**/ ?>