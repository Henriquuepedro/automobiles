<!DOCTYPE html>
<html lang="pt-BR">
    <head>
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta charset="utf-8">

        <?php echo $__env->yieldContent('css_pre'); ?>

        <!-- External CSS libraries -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/bootstrap.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/animate.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/bootstrap-submenu.css')); ?>">

        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/bootstrap-select.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/magnific-popup.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/fonts/font-awesome/css/font-awesome.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/fonts/flaticon/font/flaticon.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/fonts/linearicons/style.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/jquery.mCustomScrollbar.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/dropzone.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/slick.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/lightbox.min.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/jnoty.css')); ?>">

        <!-- Custom stylesheet -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/sidebar.css')); ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/style.css')); ?>">
        <link rel="stylesheet" type="text/css" id="style_sheet" href="<?php echo e(asset('assets/user/css/skins/yellow.css')); ?>">

        <!-- Favicon icon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/user/img/favicon.ico')); ?>" type="image/x-icon" >

        <!-- Google fonts -->
        <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,600,700%7CUbuntu:300,400,700" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600,700,800,900&display=swap" rel="stylesheet">

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/user/css/ie10-viewport-bug-workaround.css')); ?>">

        <?php echo $__env->yieldContent('css'); ?>

        <!-- Just for debugging purposes. Don't actually copy these 2 lines! -->
        <!--[if lt IE 9]><script  src="<?php echo e(asset('assets/user/js/ie8-responsive-file-warning.js')); ?>"></script><![endif]-->
        <script src="<?php echo e(asset('assets/user/js/ie-emulation-modes-warning.js')); ?>"></script>

        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!--[if lt IE 9]>
        <script src="<?php echo e(asset('assets/user/js/html5shiv.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/respond.min.js')); ?>"></script>
        <![endif]-->

        <?php echo $__env->yieldContent('js_head'); ?>
    </head>
    <body>
        <div class="page_loader"></div>

        <!-- Top header start -->
        <header class="top-header bg-active" id="top-header-2">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-7">
                        <div class="list-inline">
                            <a href="tel:<?php echo e($settings->storePhonePrimary); ?>"><i class="fa fa-phone"></i><?php echo e($settings->storePhonePrimary); ?></a>
                            <a href="tel:<?php echo e($settings->storeEmail); ?>"><i class="fa fa-envelope"></i><?php echo e($settings->storeEmail); ?></a>
                        </div>
                    </div>
                    
                </div>
            </div>
        </header>
        <!-- Top header end -->

        <!-- Main header start -->
        <header class="main-header sticky-header sh-2">
            <div class="container">
                <nav class="navbar navbar-expand-lg navbar-light">
                    <a class="navbar-brand company-logo-2" href="index.html">
                        <img src="<?php echo e($settings->logotipo); ?>" alt="logo">
                    </a>
                    <button class="navbar-toggler" type="button" id="drawer">
                        <span class="fa fa-bars"></span>
                    </button>
                    <div class="navbar-collapse collapse w-100" id="navbar">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo e(route('user.home')); ?>">Início</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link" href="<?php echo e(route('user.auto.list')); ?>">Estoque</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a href="#full-page-search" class="nav-link h-icon">
                                    <i class="fa fa-search"></i>
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
        </header>
        <!-- Main header end -->

        <!-- Sidenav start -->
        <nav id="sidebar" class="nav-sidebar">
            <!-- Close btn-->
            <div id="dismiss">
                <i class="fa fa-close"></i>
            </div>
            <div class="sidebar-inner">
                <div class="sidebar-logo">
                    <a href="index.html">
                        <img src="<?php echo e($settings->logotipo); ?>" alt="sidebarlogo">
                    </a>
                </div>
                <div class="sidebar-navigation">
                    <h3 class="heading">Pages</h3>
                    <ul class="menu-list">
                        <li>
                            <a href="<?php echo e(route('user.home')); ?>">Início</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('user.auto.list')); ?>">Estoque</a>
                        </li>
                    </ul>
                </div>
                <div class="get-in-touch">
                    <h3 class="heading">Get in Touch</h3>
                    <div class="media">
                        <i class="flaticon-phone"></i>
                        <div class="media-body">
                            <a href="tel:0477-0477-8556-552">0477 8556 552</a>
                        </div>
                    </div>
                    <div class="media">
                        <i class="flaticon-mail"></i>
                        <div class="media-body">
                            <a href="#">info@themevessel.com</a>
                        </div>
                    </div>
                    <div class="media mb-0">
                        <i class="flaticon-earth"></i>
                        <div class="media-body">
                            <a href="#">info@themevessel.com</a>
                        </div>
                    </div>
                </div>
                <div class="get-social">
                    <h3 class="heading">Get Social</h3>
                    <a href="#" class="facebook-bg">
                        <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#" class="twitter-bg">
                        <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#" class="google-bg">
                        <i class="fa fa-google"></i>
                    </a>
                    <a href="#" class="linkedin-bg">
                        <i class="fa fa-linkedin"></i>
                    </a>
                </div>
            </div>
        </nav>
        <!-- Sidenav end -->

        

        <?php echo $__env->yieldContent('body'); ?>

        

        <!-- Footer start -->
        <footer class="footer overview-bgi">
            <div class="container footer-inner">
                <div class="row">
                    <div class="col-xl-4 col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item clearfix">
                            <img src="<?php echo e($settings->logotipo); ?>" alt="logo" class="f-logo">
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <div class="text">
                                <P>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas in pulvinar neque. Nulla finibus lobortis pulvinar. Donec a consectetur nulla. Nulla posuere sapien vitae lectus suscipit, et pulvinar nisi tincidunt. Aliquam erat.</P>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item clearfix">
                            <h4>
                                Informações de Contato
                            </h4>
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <ul class="contact-info">
                                <li>
                                    <i class="flaticon-pin"></i><a href="https://www.google.com/maps/dir//<?php echo e(str_replace('/', ' - ', $settings->address)); ?>" class="address-stores-link-google" target="_blank"><?php echo e($settings->address); ?></a>
                                </li>
                                <li>
                                    <i class="flaticon-mail"></i><a href="mailto:<?php echo e($settings->storeEmail); ?>"><?php echo e($settings->storeEmail); ?></a>
                                </li>
                                <li>
                                    <?php if($settings->storeWhatsPhonePrimary): ?><i class="fa fa-whatsapp"></i><?php else: ?><i class="flaticon-phone"></i><?php endif; ?>
                                    <a href="tel:<?php echo e($settings->storePhonePrimary); ?>"><?php echo e($settings->storePhonePrimary); ?></a>
                                </li>
                                <li>
                                    <?php if($settings->storeWhatsPhoneSecondary): ?><i class="fa fa-whatsapp"></i><?php else: ?><i class="flaticon-phone"></i><?php endif; ?>
                                    <a href="tel:<?php echo e($settings->storePhoneSecondary); ?>"><?php echo e($settings->storePhoneSecondary); ?></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-2 col-lg-2 col-md-6 col-sm-6">
                        <div class="footer-item">
                            <h4>
                                Links Úteis
                            </h4>
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <ul class="links">
                                <li>
                                    <a href="<?php echo e(route('user.home')); ?>"><i class="fa fa-angle-right"></i>Home</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-lg-3 col-md-6 col-sm-6">
                        <div class="footer-item clearfix">
                            <h4>Inscreva-se</h4>
                            <div class="s-border"></div>
                            <div class="m-border"></div>
                            <div class="Subscribe-box">
                                <p>Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit.</p>
                                <form class="form-inline" action="#" method="GET">
                                    <input type="text" class="form-control mb-sm-0" id="inlineFormInputName3" placeholder="Email Address">
                                    <button type="submit" class="btn"><i class="fa fa-paper-plane"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="sub-footer">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <p class="copy">© 2019 <a href="#">Theme Vessel.</a> All Rights Reserved.</p>
                        </div>
                        <div class="col-lg-6">
                            <div class="social-list-2">
                                <ul>
                                    <?php $__currentLoopData = $settings->socialNetworks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $network): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><a href="<?php echo e($network['link']); ?>" class="<?php echo e($network['network']); ?>-bg"><i class="fa fa-<?php echo e($network['network']); ?>"></i></a></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Footer end -->

        <!-- Full Page Search -->
        <div id="full-page-search">
            <button type="button" class="close">×</button>
            <form action="index.html#">
                <input type="search" value="" placeholder="Digite sua busca aqui" />
                <button type="submit" class="btn btn-sm button-theme">Procursr</button>
            </form>
        </div>

        <!-- Car Overview Modal -->
        <div class="car-model-2">
            <div class="modal fade" id="carOverviewModal" tabindex="-1" role="dialog" aria-labelledby="carOverviewModalLabel" aria-hidden="true">
                <div class="modal-dialog modal-lg" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <div class="modal-title" id="carOverviewModalLabel">
                                <h4>Find Your Dream Car</h4>
                                <h5><i class="flaticon-pin"></i> 123 Kathal St. Tampa City,</h5>
                            </div>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="row modal-raw">
                                <div class="col-lg-6 modal-left d-flex align-self-center">
                                    <div class="item active">
                                        <img src="<?php echo e(asset('assets/user/img/car-11.png')); ?>" alt="best-car" class="img-fluid">
                                        <div class="sobuz">
                                            <div class="price-box">
                                                <span class="del-2">$1050.00</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 modal-right">
                                    <div class="modal-right-content">
                                        <section>
                                            <h3>Dados Automóvel</h3>
                                            <div class="features">
                                                <table class="auto bullets"></table>
                                                <table class="complements bullets"></table>
                                            </div>
                                        </section>
                                        <section>
                                            <h3>Opcionais</h3>
                                            <table class="optionals bullets"></table>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <script src="<?php echo e(asset('assets/user/js/jquery-2.2.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/popper.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/bootstrap-submenu.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/rangeslider.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.mb.YTPlayer.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.easing.1.3.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.scrollUp.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/dropzone.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/slick.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.filterizr.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.magnific-popup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.countdown.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jquery.mousewheel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/lightgallery-all.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/jnoty.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/sidebar.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/user/js/app.js')); ?>"></script>

        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="<?php echo e(asset('assets/user/js/ie10-viewport-bug-workaround.js')); ?>"></script>
        <!-- Custom javascript -->
        <script src="<?php echo e(asset('assets/user/js/ie10-viewport-bug-workaround.js')); ?>"></script>

        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>

<?php /**PATH C:\Projetos\sistema_carro\resources\views/user/template/page.blade.php ENDPATH**/ ?>