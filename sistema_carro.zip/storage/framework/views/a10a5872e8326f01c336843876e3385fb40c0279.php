<?php $__env->startSection('title', 'Listagem de Páginas'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('message')): ?>
        <div class="alert <?php echo e(session('typeMessage') === 'success' ? 'alert-success' : 'alert-warning'); ?>">
            <p><?php echo e(session('message')); ?></p>
        </div>
    <?php endif; ?>
    <div class="box">
        <div class="box-body">
            <div class="card">
                <div class="card-header">
                    <div class="col-md-10 pull-left">
                        <h3 class="card-title">Listagem de Páginas</h3><br/>
                        <small>Listagem de todas as páginas dinâmicas</small>
                    </div>
                    <div class="col-md-2 pull-right text-right text-xs-center">
                        <a href="<?php echo e(route('config.pageDyncamic.new')); ?>" class="btn btn-primary">Nova Página</a>
                    </div>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered table-striped dataTable" id="tablePages">
                        <thead>
                            <tr>
                                <th>Nome da Página</th>
                                <th>Situação</th>
                                <th>Ação</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $pagesDynamics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageDynamic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($pageDynamic['nome']); ?></td>
                                <td><?php echo e($pageDynamic['ativo'] ? 'ativo' : 'inativo'); ?></td>
                                <td><a href="<?php echo e(route('config.pageDyncamic.edit', ['id' => $pageDynamic['id']])); ?>" class="btn btn-primary"><i class="fa fa-pencil-alt"></i></a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Nome da Página</th>
                                <th>Situação</th>
                                <th>Ação</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.js')); ?>"></script>
    <script src="//cdn.datatables.net/plug-ins/1.10.20/i18n/Portuguese-Brasil.json"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/admin/plugins/datatables-bs4/css/dataTables.bootstrap4.css')); ?>"/>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', ['breadcrumb' => ['home' => false,'active' => 'Listagem de Páginas', 'no-active' => []]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projetos\sistema_carro\resources\views/admin/config/pageDynamic/listagem.blade.php ENDPATH**/ ?>