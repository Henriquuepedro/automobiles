<?php $__env->startSection('title', 'Cadastro Automóvel'); ?>

<?php $__env->startSection('content'); ?>
        <?php if(session('message')): ?>
            <div class="alert <?php echo e(session('typeMessage') === 'success' ? 'alert-success' : 'alert-warning'); ?>">
                <p><?php echo e(session('message')); ?></p>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Cadastro de Automóvel</h3><br/>
                        <small>Cadastro de um novo automóvel para o sistema</small>
                    </div>
                    <form action="<?php echo e(route('admin.automoveis.cadastro.save')); ?>" enctype="multipart/form-data" id="formCadastroAutos" method="POST">
                        <div class="card-body">
                            <?php if(isset($errors) && count($errors) > 0): ?>
                                <div class="alert alert-warning">
                                    <h4>Existem erros no envio do formulário, veja abaixo para corrigi-los.</h4>
                                    <ol>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ol>
                                </div>
                            <?php endif; ?>
                            <div class="error-form alert alert-warning display-none">


                                <h4>Existem erros no envio do formulário, veja abaixo para corrigi-los.</h4>
                                <ol></ol>

                            </div>
                            <div class="row">
                                <h4 class="text-primary">Informações Automóvel</h4>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="autos">Tipo Automóvel</label>
                                        <select class="form-control select2" id="autos" name="autos" title="Por favor, selecione um tipo de automóvel para continua." required disabled>
                                            <option value="">SELECIONE</option>
                                            <option value="carros">Carro</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="marcas">Marca do Automóvel</label>
                                        <select class="form-control select2" id="marcas" name="marcas" title="Por favor, selecione uma marca do automóvel para continua." required>
                                            <option value="">Selecione um tipo</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label>Modelo do Automóvel</label>
                                        <select class="form-control select2" id="modelos" name="modelos" title="Por favor, selecione um modelo do automóvel para continua." required>
                                            <option value="">Selecione uma marca</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="anos">Ano do Automóvel</label>
                                        <select class="form-control select2" id="anos" name="anos" title="Por favor, selecione um ano do automóvel para continua." required>
                                            <option value="">Selecione um modelo</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="vlrFipe">Valor Tabela FIPE Hoje</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                  <strong>R$</strong>
                                                </span>
                                            </div>
                                            <input type="text" class="form-control" id="vlrFipe" disabled>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Valor Automóvel</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text">
                                                  <strong>R$</strong>
                                                </span>
                                            </div>
                                            <input type="text" class="form-control" id="valor" name="valor" value="<?php echo e(old('valor')); ?>" title="Por favor, informe um valor para o automóvel para continua.">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label for="destaque">Destaque</label>
                                        <select class="form-control" name="destaque" id="destaque">
                                            <option value="0" <?php echo e(old('destaque') == 0 ? 'selected' : ''); ?>>Não</option>
                                            <option value="1" <?php echo e(old('destaque') == 1 ? 'selected' : ''); ?>>Sim</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Quilometragem:</label>
                                        <div class="input-group">
                                            <div class="input-group-prepend">
                                                <span class="input-group-text"><i class="fas fa-tachometer-alt"></i></span>
                                            </div>
                                            <input type="text" class="form-control" id="quilometragem" name="quilometragem" value="<?php echo e(old('quilometragem')); ?>" title="Por favor, informe a quilometragem do automóvel para continua.">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Cor do Automóvel</label>
                                        <select class="form-control select2" name="cor" id="cor" title="Por favor, selecione uma cor do automóvel para continua.">
                                            <option value="">SELECIONE</option>

                                            <?php $__currentLoopData = $dataAuto->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($color->id); ?>" <?php echo e(old('cor') == $color->id ? 'selected' : ''); ?>><?php echo e($color->nome); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Único Dono</label>
                                        <select class="form-control" name="unicoDono" title="Por favor, selecione se o automóvel é de único dono ou não para continua.">
                                            <option value="">SELECIONE</option>
                                            <option value="1" <?php echo e(old('unicoDono') == '1' ? 'selected' : ''); ?>>Sim</option>
                                            <option value="0" <?php echo e(old('unicoDono') == '0' ? 'selected' : ''); ?>>Não</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Aceita Trocas</label>
                                        <select class="form-control" name="aceitaTroca" title="Por favor, selecione se o  automóvel permite trocas ou não para continua.">
                                            <option value="" selected="selected">SELECIONE</option>
                                            <option value="1" <?php echo e(old('aceitaTroca') == '1' ? 'selected' : ''); ?>>Sim</option>
                                            <option value="0" <?php echo e(old('aceitaTroca') == '0' ? 'selected' : ''); ?>>Não</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Placa</label>
                                        <input type="text" class="form-control" id="placa" name="placa" value="<?php echo e(old('placa')); ?>" title="Por favor, informe a placa do automóvel para continua.">
                                        <small class="text-danger">Não será divulgado</small>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <hr>
                                </div>
                            </div>
                            <div class="row">
                                <h4 class="text-primary">Informações Complementares do Veículo</h4>
                            </div>
                            <div class="row" id="complements">
                                <div class="col-md-12 text-center mt-3 mb-2">
                                    <h5><i class="fas fa-exclamation-triangle"></i> Selecione um tipo de veículo para informar os dados complementares!</h5>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <hr>
                                </div>
                            </div>
                            <div class="row">
                                <h4 class="text-primary">Opcionais</h4>
                            </div>
                            <div class="row" id="optional">
                                <div class="col-md-12 text-center mt-3 mb-2">
                                    <h5><i class="fas fa-exclamation-triangle"></i> Selecione um tipo de veículo para informar os opcionais!</h5>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <hr>
                                </div>
                            </div>
                            <div class="row">
                                <h4 class="text-primary">Estado Financeiro</h4>
                            </div>
                            <div class="row">
                                <?php $__currentLoopData = $dataAuto->financials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $financialStatus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3">
                                        <div class="form-group clearfix">
                                            <div class="icheck-primary d-inline">
                                                <input type="checkbox" id="<?php echo e("financialStatus_{$financialStatus['id']}"); ?>" name="<?php echo e("financialStatus_{$financialStatus['id']}"); ?>" <?php echo e(old("financialStatus_{$financialStatus['id']}") == 'on' ? 'checked' : ''); ?>>
                                                <label for="<?php echo e("financialStatus_{$financialStatus['id']}"); ?>"><?php echo e($financialStatus['nome']); ?></label>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <hr>
                                </div>
                            </div>
                            <div class="row">
                                <h4 class="text-primary">Imagens do Automóvel</h4>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <div class="input-field">
                                            <div class="input-images" style="padding-top: .5rem;"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-footer d-flex justify-content-between flex-wrap">
                            <a href="<?php echo e(route('admin.automoveis.listagem')); ?>" class="btn btn-primary col-md-3"><i class="fa fa-arrow-left"></i> Voltar</a>
                            <button class="btn btn-success col-md-3" id="btnCadastrar"><i class="fa fa-save"></i> Cadastrar</button>
                        </div>
                        <input type="hidden" name="marcaTxt" />
                        <input type="hidden" name="modeloTxt" />
                        <input type="hidden" name="anoTxt" />
                        <input type="hidden" name="primaryImage" value="1"/>
                        <?php echo csrf_field(); ?>

                    </form>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js_head'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="https://igorescobar.github.io/jQuery-Mask-Plugin/js/jquery.mask.min.js"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/jquery-image-uploader/src/image-uploader.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/plugins/jquery-validation/dist/jquery.validate.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('admin/dist/js/pages/automovel/automovel.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css_pre'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/jquery-image-uploader/src/image-uploader.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/icheck-bootstrap/icheck-bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', ['breadcrumb' => ['home' => false,'active' => 'Cadastro Automóvel', 'no-active' => [['route' => 'admin.automoveis.listagem', 'name' => 'Listagem Automóveis']]]], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Projetos\sistema_carro\resources\views/auth/cadastros/automoveis/cadastro.blade.php ENDPATH**/ ?>